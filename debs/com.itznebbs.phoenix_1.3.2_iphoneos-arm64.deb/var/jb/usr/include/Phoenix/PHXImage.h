#import <UIKit/UIKit.h>

@interface UIImage (Phoenix)
+ (id)_applicationIconImageForBundleIdentifier:(id)arg1 format:(int)arg2 scale:(double)arg3;
@end

@interface PHXImage : NSObject
+ (UIImage *)iconForBundleID:(NSString *)bundleID;
+ (UIImage *)resizedImage:(UIImage *)image newSize:(CGSize)size;
@end